﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class Bullet
    {
        private double _x, _y;
        private double _speed;
        private double _angle;

        private Bitmap _bulletImage;
        public Bullet(double x, double y, double angle) 
        {
            _x = x;
            _y = y;
            _bulletImage = SplashKit.BitmapNamed("Bullet");
            _speed = 3;
            _angle = angle;
        }

        public void Draw()
        {
            SplashKit.DrawBitmap(_bulletImage, _x, _y);
        }
        public void Move()
        {
            _x += _speed * Math.Cos(ExtensionMethod.ToRadian(_angle + 90));
            _y += _speed * Math.Sin(ExtensionMethod.ToRadian(_angle + 90));
        }

        // Read-only property
        public Bitmap getImg
        {
            get { return _bulletImage; }
        }

        // Properties
        public double Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }


    }
}
