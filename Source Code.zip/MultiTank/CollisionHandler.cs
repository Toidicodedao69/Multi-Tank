﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class CollisionHandler
    {
        public CollisionHandler()
        {
        }
        public void CheckCollision(Player p1, Player p2, List<Item> items)
        {
            CheckBulletHit(p1, p2);
            CheckItemCollision(p1, items);
            CheckItemCollision(p2, items);
            CheckBulletOutOfScreen(p1);
            CheckBulletOutOfScreen(p2);
            CheckItemOutOfScreen(items);
        }
        public void CheckBulletHit(Player p1, Player p2)
        {
            foreach (Bullet b in p2.Ammo)
            {
                if (SplashKit.BitmapCollision(p1.getImage, p1.X, p1.Y, b.getImg, b.X, b.Y))
                {
                    p1.Hit();
                }
            }
            foreach (Bullet b in p1.Ammo)
            {
                if (SplashKit.BitmapCollision(p2.getImage, p2.X, p2.Y, b.getImg, b.X, b.Y))
                {
                    p2.Hit();
                }
            }
        }

        public void CheckItemCollision(Player p, List<Item> _items)
        {
            List<Item> toRemove = new List<Item>();
            foreach (Item i in _items)
            {
                if (SplashKit.BitmapCollision(p.getImage, p.X, p.Y, i.getImg, i.X, i.Y))
                {
                    p.Items.Add(i);
                    toRemove.Add(i);
                }
            }
            foreach (Item i in toRemove)
            {
                _items.Remove(i);
            }
        }
        public void CheckBulletOutOfScreen(Player p)
        {
            List<Bullet> toRemove = new List<Bullet>();
            foreach (Bullet b in p.Ammo)
            {
                if (b.X > ScreenSize.WIDTH || b.X < 0 || b.Y > ScreenSize.HEIGHT || b.Y < 0)
                {
                    toRemove.Add(b);
                }
            }
            foreach (Bullet b in toRemove)
            {
                p.Ammo.Remove(b);
            }
        }
        public void CheckItemOutOfScreen(List<Item> items)
        {
            List<Item> toRemove = new List<Item>();
            foreach (Item i in items)
            {
                if (i.X > (ScreenSize.WIDTH - i.getImg.Width) || i.Y > (ScreenSize.HEIGHT - i.getImg.Height))
                {
                    toRemove.Add(i);
                }
            }
            foreach (Item i in toRemove)
            {
                items.Remove(i);
            }
        }
    }
}
