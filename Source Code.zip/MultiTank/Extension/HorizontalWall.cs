﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class HorizontalWall
    {
        private double _x, _y;
        private Bitmap _image;
        
        public HorizontalWall()
        {
            _image = SplashKit.BitmapNamed("Horizontal Wall");
        }
        public void Draw()
        {
            SplashKit.DrawBitmap(_image, _x, _y);
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
    }
}
