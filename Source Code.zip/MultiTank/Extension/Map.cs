﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.IO;
//using SplashKitSDK;

//namespace MultiTank
//{
  
//    public class Map
//    {
//        const float DEFAULT_X = 50;
//        const float DEFAULT_Y = 50;

//        private Bitmap[,] _map;
//        private double _startX, _startY;
//        private Bitmap _hWallImg, _vWallImg;

//        public Map()
//        {
//            _hWallImg = SplashKit.BitmapNamed("Horizontal Wall");
//            _vWallImg = SplashKit.BitmapNamed("Vertical Wall");
//            _startX = _startY = 50;
//        }

//        private void ResetXY()
//        {
//            _startX = DEFAULT_X;
//            _startY = DEFAULT_Y;
//        }
//        public void Load(string path)
//        {
//            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
//            StreamReader reader = new StreamReader(stream);

//            int row_count = reader.ReadInteger();
//            int col_count = reader.ReadInteger();

//            _map = new Bitmap[col_count, row_count];

//            for(int x = 0; x < col_count; x++)
//            {
//                string[] row = reader.ReadString();
//                for (int y = 0; y < row_count; y++)
//                {
//                   /* if (row[y] == "0")
//                    {
//                        _map[x, y] = SplashKit.BitmapNamed("Corner Wall");
//                    } */
//                    if (row[y] == "1")
//                    {
//                        _map[x, y] = SplashKit.BitmapNamed("Horizontal Wall");
//                    }
//                    if (row[y] == "2")
//                    {
//                        _map[x, y] = SplashKit.BitmapNamed("Vertical Wall");
//                    }
//                }
//            }
//            reader.Close();
//        }
//        public void Draw()
//        {
//            for(int x = 0; x < 7; x++)
//            {
//                _startX = DEFAULT_X;
//                for (int y = 0; y < 10; y++)
//                {
//                    SplashKit.DrawBitmap(_map[x, y], _startX, _startY);
//                    _startX += _hWallImg.Width;
//                }
//                _startY += _vWallImg.Height;
//            }
//            ResetXY();
//        }
//        public Bitmap[,] getMap
//        {
//            get { return _map; }
//        }
//        public Bitmap getHWall
//        {
//            get { return _hWallImg; }
//        }
//        public Bitmap getVWall
//        {
//            get { return _vWallImg; }
//        }
//    }
//}
