﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class VerticalWall
    {
        private double _x, _y;
        private Bitmap _image;

        public VerticalWall()
        {
            _image = SplashKit.BitmapNamed("Vertical Wall");
        }
        public void Draw()
        {
            SplashKit.DrawBitmap(_image, _x, _y);
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
    }
}
