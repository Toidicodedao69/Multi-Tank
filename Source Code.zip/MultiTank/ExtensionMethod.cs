﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace MultiTank
{
    public static class ExtensionMethod
    {
        public static double ToRadian(this double number)
        {
            return (Math.PI / 180) * number;
        }
    }
}
