﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class FastBullet : Item
    {
        public FastBullet(double x, double y) : base(x, y)
        {
            _ItemImg = SplashKit.BitmapNamed("Fast Bullet");
            _duration = 180;    // Equal to 3 seconds
        }
        public override void Effect(Player p)
        {
            foreach(Bullet b in p.Ammo)
            {
                if (b == null)
                {
                    continue;
                }
                else
                {
                    b.Speed = 7;
                }
            }
        }
        public override void ReverseEffect(Player p)
        {
            foreach (Bullet b in p.Ammo)
            {
                if (b == null)
                {
                    continue;
                }
                else
                {
                    b.Speed = 2;
                }
            }
        }
    }
}
