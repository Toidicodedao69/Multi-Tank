﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class GameScreen : Page
    {
        public GameScreen() 
        {
            _background = SplashKit.BitmapNamed("Game Screen");
        }
        
    }
}
