﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class GameScreenManager
    {
        private Page _currentpage;

        public GameScreenManager(Page screen)
        {
            _currentpage = screen;
        }
        public void ChangeScreen(double x, double y, Player p1, Player p2)
        {
            if (_currentpage.GetType() == new StartScreen().GetType())
            {
                if (SplashKit.MouseClicked(MouseButton.LeftButton) && _currentpage.ButtonClicked(x, y) == "start")
                {
                    _currentpage = new GameScreen();
                }
                if (SplashKit.MouseClicked(MouseButton.LeftButton) && _currentpage.ButtonClicked(x, y) == "guide")
                {
                    _currentpage = new GuideScreen();
                }
            }
            if (_currentpage.GetType() == new GuideScreen().GetType())
            {
                if ((SplashKit.MouseClicked(MouseButton.LeftButton) && (_currentpage.ButtonClicked(x, y) == "back")) || SplashKit.KeyTyped(KeyCode.EscapeKey))
                {
                    _currentpage = new StartScreen();
                }
            }
            if (_currentpage.GetType() == new GameScreen().GetType())
            {

                if (SplashKit.KeyTyped(KeyCode.EscapeKey))
                {
                    _currentpage = new StartScreen();
                }

                if (p1.Deafeat || p2.Deafeat)
                {
                    _currentpage = new ScoreScreen(p1, p2);
                }

            }
            if (_currentpage.GetType() == new ScoreScreen(p1, p2).GetType())
            {
                _currentpage.Duration--;

                if (_currentpage.Duration == 0)
                {
                    _currentpage = new GameScreen();
                }
            }

        }
        public void Draw()
        {
            _currentpage.Draw();
        }

        public Page getPage
        {
            get { return _currentpage; }
        }

    }
}
