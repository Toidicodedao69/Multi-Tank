﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class GuideScreen : Page
    {
        private Bitmap _p1Img, _p2Img, _exitbutton;
        public GuideScreen()
        {
            _background = SplashKit.BitmapNamed("Game Screen");
            _exitbutton = SplashKit.BitmapNamed("Back Button");
            _p1Img = SplashKit.BitmapNamed("First Player");
            _p2Img = SplashKit.BitmapNamed("Second Player");
        }
        public override void Draw()
        {
            base.Draw();
            SplashKit.DrawBitmap(_exitbutton, 0, ScreenSize.HEIGHT - _exitbutton.Height);
            SplashKit.DrawText("Each player controls a tank to fight against each other by shooting bullets or using items", Color.Black, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15);
            SplashKit.DrawText("Each player can fire a maximum of 5 bullets", Color.Black, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 40);
            SplashKit.DrawText("There are 4 items that will be spawned randomly", Color.Black, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 80);

            SplashKit.DrawBitmap(_p1Img, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 140, SplashKit.OptionScaleBmp(2, 2));
            SplashKit.DrawText("Player 1: Use W,S to move forward/backward", Color.Green, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 190);
            SplashKit.DrawText("Player 1: Use A,D to rotate left/right", Color.Green, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 230);

            SplashKit.DrawBitmap(_p2Img, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 290, SplashKit.OptionScaleBmp(2, 2));
            SplashKit.DrawText("Player 2: Use UP/DOWN ARROW to move forward/backward", Color.Blue, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 340);
            SplashKit.DrawText("Player 2: Use LEFT/RIGHT ARROW to rotate left/right", Color.Blue, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 20, ScreenSize.HEIGHT / 15 + 380);
        }
        public override string ButtonClicked(double x, double y)
        {
            if (SplashKit.BitmapPointCollision(_exitbutton, 0, ScreenSize.HEIGHT - _exitbutton.Height, x, y))
            {
                return "back";
            }
            return "";
        }
    }
}
