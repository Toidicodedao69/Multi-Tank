﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public abstract class Item
    {
        private double _x, _y;
        protected Bitmap _ItemImg;
        protected int _duration;
        public Item(double x, double y)
        {
            _x = x;
            _y = y;
        }
        public void Draw()
        {
            SplashKit.DrawBitmap(_ItemImg, _x, _y);
            DrawOutline();
        }
        public void DrawOutline()
        {
            SplashKit.DrawRectangle(Color.Red, _x, _y, _ItemImg.Width, _ItemImg.Height);
        }

        public abstract void Effect(Player p);
        public abstract void ReverseEffect(Player p);

        // Read-only property 
        public Bitmap getImg
        {
            get { return _ItemImg; }
        }

        // Properties
        public int Duration
        {
            get { return _duration; }
            set { _duration = value; }
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
    }
}
