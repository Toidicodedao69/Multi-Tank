﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class MiniGun : Item
    {
        public MiniGun(double x, double y) : base(x, y)
        {
            _ItemImg = SplashKit.BitmapNamed("Mini Gun");
            _duration = 210;    // Equal to 3.5 seconds
        }
        public override void Effect(Player p)
        {
            p.MaxAmmo = 999;
        }
        public override void ReverseEffect(Player p)
        {
            p.MaxAmmo = 5;
        }
    }
}
