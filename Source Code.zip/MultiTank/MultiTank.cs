﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SplashKitSDK;

namespace MultiTank
{

    public class MultiTank
    {
        private Player _player1, _player2;
        private GameScreenManager _gamescreenmanager;

        private CollisionHandler _collision;
        private List<Item> _items;
        
        public MultiTank()
        {
            _player1 = new Player1();
            _player2 = new Player2();
            double x1 = SplashKit.Rnd(ScreenSize.WIDTH);
            double y1 = SplashKit.Rnd(ScreenSize.HEIGHT);
            double x2 = SplashKit.Rnd(ScreenSize.WIDTH);
            double y2 = SplashKit.Rnd(ScreenSize.HEIGHT);

            while (x1 == x2 && y1 == y2) // Make sure players do not spawn at the same position
            {
                x1 = SplashKit.Rnd(ScreenSize.WIDTH);
                y1 = SplashKit.Rnd(ScreenSize.HEIGHT);
                x2 = SplashKit.Rnd(ScreenSize.WIDTH);
                y2 = SplashKit.Rnd(ScreenSize.HEIGHT);
            }

            _player1.X = x1;
            _player1.Y = y1;
            _player2.X = x2;
            _player2.X = y2;
            _items = new List<Item>();
            _collision = new CollisionHandler();
            _gamescreenmanager = new GameScreenManager(new StartScreen());
        }
        public void Draw()
        {
            _gamescreenmanager.Draw();

            if (_gamescreenmanager.getPage.GetType() == new GameScreen().GetType())
            {
                _player1.Draw();
                _player2.Draw();
                foreach (Bullet b in _player1.Ammo)
                {
                    b.Draw();
                }
                foreach (Bullet b in _player2.Ammo)
                {
                    b.Draw();
                }
                foreach (Item i in _items)
                {
                    i.Draw();
                }
            }
        }

        public void Update()
        {
            UpdateScore();

            _gamescreenmanager.ChangeScreen(SplashKit.MouseX(), SplashKit.MouseY(), _player1, _player2);

            NewRound();

            if (_gamescreenmanager.getPage.GetType() == new GameScreen().GetType()) 
            {
                _player1.Control();
                _player2.Control();
            
                if (SplashKit.Rnd(300) == 1 && _items.Count < 8) // Maximum number of item is 8
                {
                    SpawnItem();
                }
                foreach (Bullet b in _player1.Ammo)
                {
                    b.Move();
                }
                foreach (Bullet b in _player2.Ammo)
                {
                    b.Move();
                }
                _collision.CheckCollision(_player1, _player2, _items);

                _player1.UseItem();
                _player2.UseItem();
            }
        }
        public void SpawnItem()
        {
            int ratio = SplashKit.Rnd(1, 100);
            double x = SplashKit.Rnd(ScreenSize.WIDTH);
            double y = SplashKit.Rnd(ScreenSize.HEIGHT);

            while ((x == _player1.X && y == _player1.Y) || (x == _player2.X && y == _player2.Y)) // Make sure items do not spawn at the players' positions
            {
                x = SplashKit.Rnd(ScreenSize.WIDTH);
                y = SplashKit.Rnd(ScreenSize.HEIGHT);
            }

            if (ratio <= 30) // ~30%
            {

                _items.Add(new MiniGun(x, y));
            }
            else if (31 <= ratio && ratio <= 50) // ~20%
            {
                _items.Add(new MysteryBox(x, y));
            }
            else if (51 <= ratio && ratio <= 70) // ~20%
            {
                _items.Add(new FastBullet(x, y));
            }
            else // ~30%
            {
                _items.Add(new SpeedBoost(x, y));
            }
        }
        public void UpdateScore()
        {
            if (_gamescreenmanager.getPage.GetType() != new GameScreen().GetType() && _gamescreenmanager.getPage.GetType() != new ScoreScreen(_player1, _player2).GetType())
            {
                // Resets player's score when exits to the start screen

                _player1.Score = 0;
                _player2.Score = 0;
            }

            if (_gamescreenmanager.getPage.GetType() == new GameScreen().GetType() && (_player1.Deafeat || _player2.Deafeat))
            {
                if (_player1.Deafeat)
                {
                    _player2.Score++;
                }
                if (_player2.Deafeat)
                {
                    _player1.Score++;
                }
            }
        }
        public void NewRound()
        {
            if (_gamescreenmanager.getPage.GetType() == new GameScreen().GetType() && (_player1.Deafeat || _player2.Deafeat) || _gamescreenmanager.getPage.GetType() == new StartScreen().GetType())
            {
                // Renew players, items, and bullets
                _player1.Deafeat = false;
                _player2.Deafeat = false;
                _player1.Ammo.Clear();
                _player2.Ammo.Clear();
                _player1.Items.Clear();
                _player2.Items.Clear();

                double x1 = SplashKit.Rnd(ScreenSize.WIDTH);
                double y1 = SplashKit.Rnd(ScreenSize.HEIGHT);
                double x2 = SplashKit.Rnd(ScreenSize.WIDTH);
                double y2 = SplashKit.Rnd(ScreenSize.HEIGHT);

                while (x1 == x2 && y1 == y2) // Make sure players do not spawn at the same position
                {
                    x1 = SplashKit.Rnd(ScreenSize.WIDTH);
                    y1 = SplashKit.Rnd(ScreenSize.HEIGHT);
                    x2 = SplashKit.Rnd(ScreenSize.WIDTH);
                    y2 = SplashKit.Rnd(ScreenSize.HEIGHT);
                }

                _player1.X = x1;
                _player1.Y = y1;
                _player2.X = x2;
                _player2.X = y2;
                _items = new List<Item>();
                _collision = new CollisionHandler();
            }
        }
    }
}
