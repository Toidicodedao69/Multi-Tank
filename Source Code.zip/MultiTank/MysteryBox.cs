﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class MysteryBox : Item
    {
        private Item _item;
        public MysteryBox(double x, double y) : base(x, y)
        {
            _ItemImg = SplashKit.BitmapNamed("Mystery Box");
            switch(SplashKit.Rnd(1, 3))
            {
                case 1:
                    _item = new MiniGun(x, y);
                    break;
                case 2:
                    _item = new SpeedBoost(x, y);
                    break;
                case 3:
                    _item = new FastBullet(x, y);
                    break;
            }
            _duration = _item.Duration;
        }
        public override void Effect(Player p)
        {
            _item.Effect(p);
        }
        public override void ReverseEffect(Player p)
        {
            _item.ReverseEffect(p);
        }
    }
}