﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class Page
    {
        protected Bitmap _background;
        protected int _duration;
        public Page() { }

        public virtual void Draw()
        {
            SplashKit.DrawBitmap(_background, 0, 0);
        }
        public virtual string ButtonClicked(double x, double y)
        {
            return "";
        }
        public int Duration
        {
            get { return _duration; }
            set { _duration = value; }
        }
    }
}
