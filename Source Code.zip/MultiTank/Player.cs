﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SplashKitSDK;

namespace MultiTank
{
    public abstract class Player
    {
        
        protected double _x, _y; // Position of the tank
        protected double _angle; // The angle which the tank is facing; 0 is north and 180 is south
        protected double _forwardspeed, _backwardspeed; // Moving forward and backward speed
        private double _rotationspeed; // Rotation speed

        protected int _maxammo; // Maximum number of bullets 
        protected int _score;
        protected Bitmap _tankImage;
        protected List<Bullet> _ammo;
        protected List<Item> _items; // A list of item will be used by player

        protected bool _dead; // Check state of player; true = dead, false = alive
        
        public Player()
        {
            _angle = (int)SplashKit.Rnd(360);

            _forwardspeed = 2;
            _backwardspeed = 1;
            _rotationspeed = 5;
            _maxammo = 5;
            _score = 0;

            _dead = false;

            _ammo = new List<Bullet>();
            _items = new List<Item>();
        }
        
        public void RotateRight()
        {
            _angle += _rotationspeed;
            if (_angle > 359)
            {
                _angle -= 360;
            }
        }
        public void RotateLeft()
        {
            _angle -= _rotationspeed;
            if (_angle < 0)
            {
                _angle += 360;
            }
        }
        public void UseItem()
        {
            List<Item> toRemove = new List<Item>();
            foreach (Item i in _items)
            {
                i.Duration -= 1;
                i.Effect(this);

                if (i.Duration == 0)
                {
                    i.ReverseEffect(this);
                    toRemove.Add(i);
                }
            }
            foreach (Item i in toRemove)
            {
                _items.Remove(i);
            }
        }
        public void Shoot()
        {
            if (_ammo.Count < _maxammo)
            {
                Bullet b = new Bullet(_x + _tankImage.Width / 2, _y + _tankImage.Height / 2, _angle);
                _ammo.Add(b);
            }
        }

        public abstract void Draw();

        public virtual void Control()
        {
            // If player moves out of screen
            if (_x < 0)
            {
                _x += ScreenSize.WIDTH;
            }
            if (_x > ScreenSize.WIDTH)
            {
                _x -= ScreenSize.WIDTH;
            }
            if (_y < 0)
            {
                _y += ScreenSize.HEIGHT;
            }
            if (_y > ScreenSize.HEIGHT)
            {
                _y -= ScreenSize.HEIGHT;
            }
        }

        public void Hit()
        {
            _dead = true;
        }

        // Read-only properties
        public List<Bullet> Ammo
        {
            get { return _ammo; }
        }
        public List<Item> Items
        {
            get { return _items; }
        }
        public Bitmap getImage
        {
            get { return _tankImage; }
        }

        // Properties
        public bool Deafeat
        {
            get { return _dead; }
            set { _dead = value; }
        }
        public int Score
        {
            get { return _score; }
            set { _score = value; }
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
        public int MaxAmmo
        {
            get { return _maxammo; }
            set { _maxammo = value; }
        }
        public double ForwardSpeed
        {
            get { return _forwardspeed; }
            set { _forwardspeed = value; }
        }
        public double BackwardSpeed
        {
            get { return _backwardspeed; }
            set { _backwardspeed = value; }
        }
    }
}
