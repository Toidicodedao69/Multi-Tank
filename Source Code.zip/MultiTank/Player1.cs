﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SplashKitSDK;

namespace MultiTank
{
    public class Player1 : Player
    {
        public Player1() 
        {
            _tankImage = SplashKit.BitmapNamed("First Player");
        }
        public override void Draw()
        {
            if (_dead)
            {
                SplashKit.DrawBitmap(SplashKit.BitmapNamed("Explosion"), _x, _y);
            }
            else 
            {
                SplashKit.DrawBitmap(_tankImage, _x, _y, SplashKit.OptionRotateBmp(_angle));
            }
        }

        public override void Control()
        {
            base.Control();
            if (SplashKit.KeyDown(KeyCode.DKey))
            {
                RotateRight();
            }
            if (SplashKit.KeyDown(KeyCode.AKey))
            {
                RotateLeft();
            }
            if (SplashKit.KeyDown(KeyCode.WKey)) // Move forward
            {
                _x += _forwardspeed * Math.Cos(ExtensionMethod.ToRadian(_angle + 90));
                _y += _forwardspeed * Math.Sin(ExtensionMethod.ToRadian(_angle + 90));
            } 
            if (SplashKit.KeyDown(KeyCode.SKey)) // Move backward
            {
                _x -= _forwardspeed * Math.Cos(ExtensionMethod.ToRadian(_angle + 90));
                _y -= _forwardspeed * Math.Sin(ExtensionMethod.ToRadian(_angle + 90));
            }
            // How to shoot
            if (SplashKit.KeyTyped(KeyCode.QKey))
            {
                Shoot();
            }
        }
    }
}
