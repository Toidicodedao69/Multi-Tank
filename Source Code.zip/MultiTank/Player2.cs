﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class Player2 : Player
    {
        public Player2()
        {
            _tankImage = SplashKit.BitmapNamed("Second Player");
        }
        public override void Draw()
        {
            if (_dead)
            {
                SplashKit.DrawBitmap(SplashKit.BitmapNamed("Explosion"), _x, _y);
            }
            else
            {
                SplashKit.DrawBitmap(_tankImage, _x, _y, SplashKit.OptionRotateBmp(_angle));
            }
        }
        public override void Control()
        {
            base.Control();
            if (SplashKit.KeyDown(KeyCode.RightKey))
            {
                RotateRight();
            }
            if (SplashKit.KeyDown(KeyCode.LeftKey))
            {
                RotateLeft();
            }
            if (SplashKit.KeyDown(KeyCode.UpKey)) // Move forward
            {
                _x += _forwardspeed * Math.Cos(ExtensionMethod.ToRadian(_angle + 90));
                _y += _forwardspeed * Math.Sin(ExtensionMethod.ToRadian(_angle + 90));
            }
            if (SplashKit.KeyDown(KeyCode.DownKey)) // Move backward
            {
                _x -= _forwardspeed * Math.Cos(ExtensionMethod.ToRadian(_angle + 90));
                _y -= _forwardspeed * Math.Sin(ExtensionMethod.ToRadian(_angle + 90));
            }
            // How to shoot
            if (SplashKit.KeyTyped(KeyCode.MKey))
            {
                Shoot();
            }
        }
    }
}

