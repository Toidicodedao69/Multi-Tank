using System;
using SplashKitSDK;

namespace MultiTank
{
    public class Program
    {
        public static void LoadResources() // Load game images
        {
            SplashKit.LoadBitmap("First Player", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\FirstPlayer.png");
            SplashKit.LoadBitmap("Second Player", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\SecondPlayer.png");

            SplashKit.LoadBitmap("Bullet", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\Bullet.png");
            SplashKit.LoadBitmap("Explosion", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\Explosion.png");

            SplashKit.LoadBitmap("Speed Boost", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\SpeedBoost.png");
            SplashKit.LoadBitmap("Mini Gun", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\MiniGun.png");
            SplashKit.LoadBitmap("Mystery Box", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\MysteryBox.png");
            SplashKit.LoadBitmap("Fast Bullet", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\FastBullet.png");

            SplashKit.LoadBitmap("Title", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\Title.png");
            SplashKit.LoadBitmap("Start Screen", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\StartScreen.png");
            SplashKit.LoadBitmap("Game Screen", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\Background.png");
            SplashKit.LoadBitmap("Back Button", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\BackButton.png");
            SplashKit.LoadBitmap("Guide Button", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\GuideButton.png");
            SplashKit.LoadBitmap("Start Button", "E:\\Swinburne 2021 - 2024\\SEM 2 2022\\COS20007 - OOP\\Custom Program\\MultiTank\\Images\\StartButton.png");
        }
        public static void Main()
        {
            LoadResources();

            MultiTank _game = new MultiTank();

            // open the game window
            Window window = new Window("Multi Tank", ScreenSize.WIDTH, ScreenSize.HEIGHT);

            // run the game loop
            while (!window.CloseRequested)
            {
                // fetch the next batch of UI interaction
                SplashKit.ProcessEvents();

                _game.Update();

                // clear the screen to white
                SplashKit.ClearScreen(Color.White);

                // draw everything in the game
                _game.Draw();

                // draw onto the screen, limit to 60fps
                SplashKit.RefreshScreen(60);
            }
        }
    }
}
