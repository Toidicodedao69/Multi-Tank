﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class ScoreScreen : Page
    {
        private Player _p1, _p2;
        public ScoreScreen(Player p1, Player p2)
        {
            _background = SplashKit.BitmapNamed("Game Screen");

            _p1 = p1;
            _p2 = p2;
            _duration = 120;
        }
        public override void Draw()
        {
            base.Draw();
            SplashKit.DrawBitmap(_p1.getImage, ScreenSize.WIDTH / 4, ScreenSize.HEIGHT / 3, SplashKit.OptionScaleBmp(3, 3));
            SplashKit.DrawBitmap(_p2.getImage, ScreenSize.WIDTH * 3 / 4, ScreenSize.HEIGHT / 3, SplashKit.OptionScaleBmp(3, 3));

            SplashKit.DrawText(_p1.Score.ToString(), Color.Black, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH / 4 + 10, ScreenSize.HEIGHT / 3 + 70);
            SplashKit.DrawText(_p2.Score.ToString(), Color.Black, SplashKit.FontNamed("Normal Font"), 100, ScreenSize.WIDTH * 3 / 4 + 10, ScreenSize.HEIGHT / 3 + 70);
        }
    }
}
