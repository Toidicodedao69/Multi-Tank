﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MultiTank
{
    public sealed class ScreenSize
    {
        private static readonly ScreenSize size = new ScreenSize();

        static ScreenSize()
        {
        }
        private ScreenSize()
        {
        }

        public static ScreenSize Size
        {
            get
            {
                return size;
            }
        }
        public const int WIDTH = 800;
        public const int HEIGHT = 600;
    }
}
