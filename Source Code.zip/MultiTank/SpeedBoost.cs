﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class SpeedBoost : Item
    {
        public SpeedBoost(double x, double y) : base(x, y)
        {
            _ItemImg = SplashKit.BitmapNamed("Speed Boost");
            _duration = 300;        // Equals to 5 seconds
        }
        public override void Effect(Player p)
        {
            _duration--;
            p.ForwardSpeed = 4;
            p.BackwardSpeed = 2;
        }
        public override void ReverseEffect(Player p)
        {
            p.ForwardSpeed = 2;
            p.BackwardSpeed = 1;
        }
    }
}
