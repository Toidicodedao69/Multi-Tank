﻿using System;
using System.Collections.Generic;
using System.Text;
using SplashKitSDK;

namespace MultiTank
{
    public class StartScreen : Page
    {
        private Bitmap _guidebutton, _title, _startbutton;
        public StartScreen()
        {
            _title = SplashKit.BitmapNamed("Title");
            _background = SplashKit.BitmapNamed("Start Screen");
            _startbutton = SplashKit.BitmapNamed("Start Button"); // start button
            _guidebutton = SplashKit.BitmapNamed("Guide Button"); // how to play button
        }
        public override void Draw()
        {
            base.Draw();
            SplashKit.DrawBitmap(_title, ScreenSize.WIDTH / 3 - 30, ScreenSize.HEIGHT / 8);
            SplashKit.DrawBitmap(_startbutton, ScreenSize.WIDTH / 3, ScreenSize.HEIGHT - 200);
            SplashKit.DrawBitmap(_guidebutton, ScreenSize.WIDTH / 3, ScreenSize.HEIGHT - 120);
        }
        public override string ButtonClicked(double x, double y)
        {
            if (SplashKit.BitmapPointCollision(_startbutton, ScreenSize.WIDTH / 3, ScreenSize.HEIGHT - 200, x, y))
            {
                return "start";
            }
            if (SplashKit.BitmapPointCollision(_guidebutton, ScreenSize.WIDTH / 3, ScreenSize.HEIGHT - 120, x, y))
            {
                return "guide";
            }
            return "";
        }

    }
}
